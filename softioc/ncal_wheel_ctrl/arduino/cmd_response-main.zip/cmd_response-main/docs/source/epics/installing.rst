.. index:: EPICS; Installing

.. _installing.epics:

================
Installing EPICS
================

.. toctree::
   :maxdepth: 2
   :glob:
   
   rpi_epics

Installing EPICS is a bit more challenging that just a simple download.
A full description is presented in :ref:`rpi_epics`.
